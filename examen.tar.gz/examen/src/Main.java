public class Main {
    public static void main(String[] args){

        Controlador c = new Controlador();

        c.inicioprograma();



    }
}
