public class Nacion {

    private String nombre;

    Nacion (){
        this.nombre = nombre;
    }



    public void setNombre (String nombre) {

        this.nombre = nombre;
    }

    public String getNombre () {

        return nombre;
    }

}
