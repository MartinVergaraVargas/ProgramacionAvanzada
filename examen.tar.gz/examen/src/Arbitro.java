public class Arbitro {
}
