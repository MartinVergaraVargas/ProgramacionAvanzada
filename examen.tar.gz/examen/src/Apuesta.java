public class Apuesta {
}
